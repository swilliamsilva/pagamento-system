import React from 'react';
import { usePayment } from '../contexts/PaymentContext';
import PaymentMethodSelector from '../components/PaymentMethodSelector/PaymentMethodSelector';
import PixDisplay from '../components/PixDisplay/PixDisplay';
import BoletoDisplay from '../components/BoletoDisplay/BoletoDisplay';
import CardForm from '../components/CardForm/CardForm';
import PaymentStatus from '../components/PaymentStatus/PaymentStatus';
import './PaymentPage.css';

const PaymentPage = () => {
  const {
    selectedMethod,
    paymentStatus,
    paymentData,
    errorMessage,
    selectMethod,
    submitCardPayment,
    resetPayment, // Get reset function from context
  } = usePayment();

  // Placeholder for total amount - this should come from props or context
  const totalAmount = 100.00; // Example amount

  const renderPaymentDetails = () => {
    if (paymentStatus === 'success' || paymentStatus === 'error' || paymentStatus === 'processing') {
        // Show status component prominently if there's an active status
        return <PaymentStatus status={paymentStatus} message={errorMessage || paymentData.message} />;
    }

    switch (selectedMethod) {
      case 'pix':
        return <PixDisplay qrCodeValue={paymentData.qrCodeValue} copyPasteCode={paymentData.copyPasteCode} />;
      case 'boleto':
        return <BoletoDisplay barcodeValue={paymentData.barcodeValue} digitableLine={paymentData.digitableLine} />;
      case 'credit_card':
      case 'debit_card':
        return <CardForm onSubmit={submitCardPayment} />;
      case 'picpay':
        // Placeholder for PicPay - Replace with actual component later
        return (
          <div className="picpay-placeholder">
            <h3>Pagamento com PicPay</h3>
            <p>{paymentData.message || 'Siga as instruções no seu app PicPay para concluir o pagamento.'}</p>
            {/* Add QR code or button if needed based on PicPay integration */} 
          </div>
        );
      default:
        return <p className="select-method-prompt">Selecione um método de pagamento acima.</p>;
    }
  };

  return (
    <div className="payment-page-container">
      <header className="payment-header">
        <h1>Portal de Pagamento</h1>
        {/* Displaying a mock total amount */} 
        <div className="total-amount">
          Total a Pagar: <span>R$ {totalAmount.toFixed(2).replace('.', ',')}</span>
        </div>
      </header>
      
      {/* Show selector only if no final status is reached or if user wants to go back */} 
      {paymentStatus !== 'success' && (
          <PaymentMethodSelector selectedMethod={selectedMethod} onSelectMethod={selectMethod} />
      )}

      <div className="payment-details-section">
        {renderPaymentDetails()}
      </div>

      {/* Button to reset/start over, shown after selection or error */} 
      {(selectedMethod && paymentStatus !== 'processing' && paymentStatus !== 'success') && (
          <button onClick={resetPayment} className="reset-button">
              Escolher Outro Método / Cancelar
          </button>
      )}

    </div>
  );
};

export default PaymentPage;

