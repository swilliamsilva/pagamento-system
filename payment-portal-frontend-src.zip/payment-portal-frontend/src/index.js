import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/global.css'; // Import global styles first
import App from './App';
import { PaymentProvider } from './contexts/PaymentContext';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <PaymentProvider>
      <App />
    </PaymentProvider>
  </React.StrictMode>
);

