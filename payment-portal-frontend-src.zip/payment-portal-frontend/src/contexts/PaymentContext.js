import React, { createContext, useState, useContext } from 'react';

const PaymentContext = createContext();

export const usePayment = () => useContext(PaymentContext);

export const PaymentProvider = ({ children }) => {
  const [selectedMethod, setSelectedMethod] = useState(null); // e.g., 'pix', 'boleto', 'credit_card', 'debit_card', 'picpay'
  const [paymentStatus, setPaymentStatus] = useState(null); // e.g., null, 'processing', 'success', 'error'
  const [paymentData, setPaymentData] = useState({}); // To store data like QR code, barcode, etc.
  const [errorMessage, setErrorMessage] = useState('');

  // --- Mock API Interaction Logic (Replace with actual API calls) ---

  const initiatePayment = async (method, details = {}) => {
    console.log(`Initiating payment for: ${method}`, details);
    setPaymentStatus('processing');
    setErrorMessage('');
    setPaymentData({}); // Clear previous data

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Mock backend response based on method
      if (method === 'pix') {
        // Simulate receiving QR code and copy/paste data
        setPaymentData({
          qrCodeValue: `mock_qr_code_for_${Date.now()}`,
          copyPasteCode: `mock_copia_e_cola_${Date.now()}`
        });
        // For Pix/Boleto, status might stay 'processing' until confirmation
        // setPaymentStatus(null); // Or keep processing until webhook/poll confirms
      } else if (method === 'boleto') {
        // Simulate receiving barcode and digitable line
        setPaymentData({
          barcodeValue: `12345678901234567890123456789012345678901234`, // Example barcode data
          digitableLine: `12345.67890 12345.678901 23456.789012 3 45678901234` // Example digitable line
        });
         // setPaymentStatus(null); // Or keep processing
      } else if (method === 'credit_card' || method === 'debit_card') {
        // Simulate card processing result
        const isSuccess = Math.random() > 0.3; // Simulate 70% success rate
        if (isSuccess) {
          setPaymentStatus('success');
        } else {
          setPaymentStatus('error');
          setErrorMessage('Pagamento com cartão recusado. Verifique os dados.');
        }
      } else if (method === 'picpay') {
          // Simulate PicPay interaction (e.g., show instructions or redirect)
          setPaymentData({ message: 'Siga as instruções no app PicPay para concluir.' });
          // PicPay status might also depend on external confirmation
          // setPaymentStatus(null);
      } else {
          throw new Error('Método de pagamento desconhecido');
      }
      // If Pix/Boleto, don't set status to success/error here, wait for confirmation
      if (method !== 'pix' && method !== 'boleto' && method !== 'picpay' && paymentStatus !== 'error') {
           // Only set status to null if it wasn't an error during card processing
           // Keep 'processing' for methods needing confirmation
      }

    } catch (error) {
      console.error("Payment initiation error:", error);
      setPaymentStatus('error');
      setErrorMessage(error.message || 'Ocorreu um erro inesperado.');
    }
  };

  const handleSelectMethod = (methodId) => {
    setSelectedMethod(methodId);
    setPaymentStatus(null); // Reset status when changing method
    setErrorMessage('');
    setPaymentData({});
    // For Pix/Boleto/PicPay, initiate immediately to get data
    if (['pix', 'boleto', 'picpay'].includes(methodId)) {
      initiatePayment(methodId);
    }
  };

  const handleCardSubmit = (cardDetails) => {
    // Card form submits, then we initiate payment
    initiatePayment(cardDetails.cardType === 'credit' ? 'credit_card' : 'debit_card', cardDetails);
  };

  const resetPayment = () => {
      setSelectedMethod(null);
      setPaymentStatus(null);
      setPaymentData({});
      setErrorMessage('');
  }

  const value = {
    selectedMethod,
    paymentStatus,
    paymentData,
    errorMessage,
    selectMethod: handleSelectMethod,
    submitCardPayment: handleCardSubmit,
    resetPayment, // Add reset function to context
  };

  return (
    <PaymentContext.Provider value={value}>
      {children}
    </PaymentContext.Provider>
  );
};

