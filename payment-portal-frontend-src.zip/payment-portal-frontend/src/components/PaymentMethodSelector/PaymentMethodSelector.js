import React from 'react';
import './PaymentMethodSelector.css';

// Placeholder data - replace with actual data/logic
const paymentMethods = [
  { id: 'boleto', name: 'Boleto', icon: '📄' },
  { id: 'pix', name: 'Pix', icon: '✨' },
  { id: 'credit_card', name: 'Cartão de Crédito', icon: '💳' },
  { id: 'debit_card', name: 'Cartão de Débito', icon: '💳' },
  { id: 'picpay', name: 'PicPay', icon: '🅿️' }, // Assuming PicPay is an option
];

const PaymentMethodSelector = ({ selectedMethod, onSelectMethod }) => {
  return (
    <div className="payment-selector-container">
      <h2>Escolha a forma de pagamento:</h2>
      <div className="payment-options">
        {paymentMethods.map((method) => (
          <button
            key={method.id}
            className={`payment-option ${selectedMethod === method.id ? 'selected' : ''}`}
            onClick={() => onSelectMethod(method.id)}
          >
            <span className="payment-icon">{method.icon}</span>
            <span className="payment-name">{method.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default PaymentMethodSelector;

