import React from 'react';
import Barcode from 'react-barcode';
import './BoletoDisplay.css';

const BoletoDisplay = ({ barcodeValue, digitableLine }) => {

  const handleCopy = () => {
    navigator.clipboard.writeText(digitableLine)
      .then(() => {
        alert('Linha digitável copiada para a área de transferência!');
        // Maybe show a temporary success message instead of alert
      })
      .catch(err => {
        console.error('Erro ao copiar linha digitável: ', err);
        alert('Não foi possível copiar a linha digitável.');
      });
  };

  if (!barcodeValue || !digitableLine) {
    // Placeholder or loading state while waiting for backend data
    return <div className="boleto-container">Gerando informações do Boleto...</div>;
  }

  return (
    <div className="boleto-container">
      <h3>Pague com Boleto</h3>
      <p>Utilize o código de barras ou a linha digitável abaixo:</p>
      <div className="barcode-wrapper">
        {/* Adjust barcode options as needed (width, height, format, etc.) */}
        <Barcode value={barcodeValue} width={2} height={80} displayValue={false} />
      </div>
      <p>Linha Digitável:</p>
      <div className="digitable-line-section">
        <input type="text" value={digitableLine} readOnly className="digitable-line-input" />
        <button onClick={handleCopy} className="copy-button">Copiar Linha</button>
      </div>
      <p className="boleto-instructions">O pagamento pode levar até 3 dias úteis para ser confirmado.</p>
    </div>
  );
};

export default BoletoDisplay;

