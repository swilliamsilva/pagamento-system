import React from 'react';
import './PaymentStatus.css';

const PaymentStatus = ({ status, message }) => {
  if (!status) {
    return null; // Don't render if no status is set
  }

  let icon = '';
  let statusClass = '';

  switch (status) {
    case 'processing':
      icon = '⏳'; // Hourglass
      statusClass = 'processing';
      message = message || 'Processando pagamento...';
      break;
    case 'success':
      icon = '✅'; // Check mark
      statusClass = 'success';
      message = message || 'Pagamento aprovado com sucesso!';
      break;
    case 'error':
      icon = '❌'; // Cross mark
      statusClass = 'error';
      message = message || 'Erro ao processar pagamento. Tente novamente.';
      break;
    default:
      return null; // Unknown status
  }

  return (
    <div className={`payment-status-container ${statusClass}`}>
      <span className="status-icon">{icon}</span>
      <p className="status-message">{message}</p>
      {/* Optionally add a button to retry or go back */} 
      {status === 'error' && (
          <button onClick={() => window.location.reload()} className="retry-button">
              Tentar Novamente
          </button>
      )}
       {status === 'success' && (
          <button onClick={() => window.location.reload()} className="new-payment-button">
              Novo Pagamento
          </button>
      )}
    </div>
  );
};

export default PaymentStatus;

