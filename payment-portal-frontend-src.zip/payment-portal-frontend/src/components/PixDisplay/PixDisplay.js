import React from 'react';
import QRCode from 'qrcode.react';
import './PixDisplay.css';

const PixDisplay = ({ qrCodeValue, copyPasteCode }) => {

  const handleCopy = () => {
    navigator.clipboard.writeText(copyPasteCode)
      .then(() => {
        alert('Código Pix copiado para a área de transferência!');
        // Maybe show a temporary success message instead of alert
      })
      .catch(err => {
        console.error('Erro ao copiar código Pix: ', err);
        alert('Não foi possível copiar o código Pix.');
      });
  };

  if (!qrCodeValue || !copyPasteCode) {
    // Placeholder or loading state while waiting for backend data
    return <div className="pix-container">Gerando informações do Pix...</div>;
  }

  return (
    <div className="pix-container">
      <h3>Pague com Pix</h3>
      <p>Escaneie o QR Code abaixo com o app do seu banco:</p>
      <div className="qr-code-wrapper">
        <QRCode value={qrCodeValue} size={200} level="H" />
      </div>
      <p>Ou copie o código abaixo (Pix Copia e Cola):</p>
      <div className="copy-paste-section">
        <input type="text" value={copyPasteCode} readOnly className="copy-paste-input" />
        <button onClick={handleCopy} className="copy-button">Copiar Código</button>
      </div>
      <p className="pix-instructions">Após o pagamento, a confirmação será automática.</p>
    </div>
  );
};

export default PixDisplay;

