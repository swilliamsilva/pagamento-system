import React, { useState } from 'react';
import './CardForm.css';

const CardForm = ({ onSubmit }) => {
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState(''); // MM/AA format
  const [cvv, setCvv] = useState('');
  const [cardType, setCardType] = useState('credit'); // 'credit' or 'debit'
  const [error, setError] = useState('');

  const handleCardNumberChange = (e) => {
    // Basic formatting (add spaces) - consider a library for robust formatting
    const value = e.target.value.replace(/\D/g, ''); // Remove non-digits
    const formattedValue = value.replace(/(.{4})/g, '$1 ').trim();
    setCardNumber(formattedValue.slice(0, 19)); // Limit length (e.g., 16 digits + 3 spaces)
  };

  const handleExpiryDateChange = (e) => {
    // Basic formatting (MM/AA)
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    setExpiryDate(value.slice(0, 5)); // Limit to MM/AA
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Basic validation - enhance this significantly for production
    if (!cardNumber || cardNumber.replace(/\s/g, '').length < 13) {
      setError('Número do cartão inválido.');
      return;
    }
    if (!cardName) {
      setError('Nome no cartão é obrigatório.');
      return;
    }
    if (!expiryDate || !/^\d{2}\/\d{2}$/.test(expiryDate)) {
      setError('Data de validade inválida (MM/AA).');
      return;
    }
    if (!cvv || cvv.length < 3 || cvv.length > 4) {
      setError('CVV inválido.');
      return;
    }

    // Pass data to parent component/context for backend submission
    onSubmit({ 
        cardNumber: cardNumber.replace(/\s/g, ''), // Send without spaces
        cardName, 
        expiryDate, 
        cvv, 
        cardType 
    });
  };

  return (
    <form className="card-form-container" onSubmit={handleSubmit}>
      <h3>Pagamento com Cartão</h3>
      <div className="card-type-selector">
        <label>
          <input 
            type="radio" 
            name="cardType" 
            value="credit" 
            checked={cardType === 'credit'} 
            onChange={() => setCardType('credit')} 
          /> Crédito
        </label>
        <label>
          <input 
            type="radio" 
            name="cardType" 
            value="debit" 
            checked={cardType === 'debit'} 
            onChange={() => setCardType('debit')} 
          /> Débito
        </label>
      </div>
      <div className="form-group">
        <label htmlFor="cardNumber">Número do Cartão</label>
        <input
          type="text" // Use text for formatting
          id="cardNumber"
          value={cardNumber}
          onChange={handleCardNumberChange}
          placeholder="0000 0000 0000 0000"
          maxLength="19"
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="cardName">Nome no Cartão</label>
        <input
          type="text"
          id="cardName"
          value={cardName}
          onChange={(e) => setCardName(e.target.value)}
          placeholder="Como impresso no cartão"
          required
        />
      </div>
      <div className="form-row">
        <div className="form-group half-width">
          <label htmlFor="expiryDate">Validade (MM/AA)</label>
          <input
            type="text" // Use text for formatting
            id="expiryDate"
            value={expiryDate}
            onChange={handleExpiryDateChange}
            placeholder="MM/AA"
            maxLength="5"
            required
          />
        </div>
        <div className="form-group half-width">
          <label htmlFor="cvv">CVV</label>
          <input
            type="password" // Mask CVV
            id="cvv"
            value={cvv}
            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
            placeholder="123"
            maxLength="4"
            required
          />
        </div>
      </div>
      {error && <p className="error-message">{error}</p>}
      <button type="submit" className="submit-button">Pagar com Cartão</button>
    </form>
  );
};

export default CardForm;

