import React from 'react';
import PaymentPage from './pages/PaymentPage';
import './App.css'; // Optional: for App-level styles if needed

function App() {
  return (
    <div className="App">
      <PaymentPage />
    </div>
  );
}

export default App;

