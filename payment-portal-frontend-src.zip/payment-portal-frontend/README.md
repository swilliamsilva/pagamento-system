# Portal de Pagamentos - Frontend React (Estrutura Inicial)

Este é o repositório da estrutura inicial do frontend em React para o portal de pagamentos.

## Visão Geral

O projeto foi criado com `create-react-app` e estruturado para suportar múltiplos métodos de pagamento (Boleto, Pix, Cartão Débito/Crédito, PicPay) com um design em tons de azul, conforme solicitado.

Utiliza a Context API (`src/contexts/PaymentContext.js`) para gerenciamento básico do estado do pagamento (método selecionado, status, dados do pagamento). A lógica de comunicação com o backend (simulada no contexto por enquanto) deve ser implementada em `src/services/api.js`.

## Estrutura de Pastas

```
payment-portal-frontend/
├── public/
├── src/
│   ├── assets/
│   ├── components/         # Componentes visuais (BoletoDisplay, CardForm, etc.)
│   ├── contexts/           # PaymentContext.js
│   ├── hooks/
│   ├── pages/              # PaymentPage.js
│   ├── services/           # api.js (para chamadas ao backend Java)
│   ├── styles/             # global.css, theme.css (tons de azul)
│   ├── utils/
│   ├── App.js
│   └── index.js
├── .gitignore
├── package.json
└── README.md
```

(Consulte `payment-portal-planning.md` para mais detalhes sobre o planejamento).

## Componentes Implementados (Estrutura Básica)

*   `PaymentMethodSelector`: Permite ao usuário escolher o método de pagamento.
*   `PixDisplay`: Exibe QR Code e código Copia e Cola (requer dados do backend).
*   `BoletoDisplay`: Exibe Código de Barras e Linha Digitável (requer dados do backend).
*   `CardForm`: Formulário para inserção de dados de cartão (Débito/Crédito).
*   `PaymentStatus`: Exibe o status do pagamento (Processando, Sucesso, Erro).
*   `PaymentPage`: Orquestra os componentes e o fluxo na página principal.

**Nota:** O componente PicPay é apenas um placeholder e precisa ser desenvolvido com base nos requisitos específicos da integração PicPay.

## Como Executar

1.  **Descompacte** o arquivo `.zip` fornecido.
2.  Navegue até o diretório `payment-portal-frontend` no seu terminal:
    ```bash
    cd payment-portal-frontend
    ```
3.  Instale as dependências:
    ```bash
    npm install
    ```
4.  Inicie o servidor de desenvolvimento:
    ```bash
    npm start
    ```
    A aplicação estará disponível em `http://localhost:3000` (ou outra porta, se a 3000 estiver ocupada).

## Próximos Passos Sugeridos

1.  **Integração com Backend:** Substituir a lógica mock no `PaymentContext.js` e `src/services/api.js` pelas chamadas reais aos endpoints do seu backend Java.
2.  **Desenvolvimento PicPay:** Implementar o fluxo e a interface específica para o pagamento via PicPay.
3.  **Validação de Formulários:** Aprimorar a validação no `CardForm.js` (considerar bibliotecas como `react-hook-form` ou `formik` e validação de número de cartão, como o algoritmo de Luhn).
4.  **Estilização Fina:** Ajustar os estilos CSS para corresponder exatamente ao design desejado.
5.  **Tratamento de Erros:** Melhorar a exibição e o tratamento de erros vindos do backend.
6.  **Testes:** Adicionar testes unitários e de integração.

